import React, { Component } from 'react';
import './App.css';
import web3 from './web3';
//import factory from './factory';
import {abi,address} from './factory';
var factory = new web3.eth.Contract(abi,address);

class SendItem extends Component {
  state = {
    name: '',
    count: '',
    receiver: '',
    value: '',
    message: ''
  };
  onSubmit = async event => {
    event.preventDefault();

    const accounts = await web3.eth.getAccounts();
    
    this.setState({ message: 'Waiting on transaction success...' });
    var result = await factory.methods._sendItem(this.state.name,this.state.count,this.state.receiver).send({
      from: accounts[0]
    });
    console.log(result.events.Deposit.returnValues._from);
    console.log(result.events.Deposit.returnValues._to); //ye wala value
    this.props.syncAddress(result.events.Deposit.returnValues._to);
    console.log(result.events.Deposit.returnValues._value);
    console.log("I am here");
    this.setState({ message: 'Transaction Successful' });
  };
  render() {
    return(
      <div className="box">
        <form onSubmit={this.onSubmit}>
          <h4>Send Item</h4>
          <div className="inB">
            <label>Enter item name</label>
            <input
              value={this.state.name}
              onChange={event => this.setState({ name: event.target.value })}
            />
          </div>
          <div className="inB">
            <label>Enter item count</label>
            <input
              value={this.state.count}
              onChange={event => this.setState({ count: event.target.value })}
            />
          </div>
          <div className="inB">
            <label>Enter receiver address</label>
            <input
              value={this.state.receiver}
              onChange={event => this.setState({ receiver: event.target.value })}
            />
          </div>
          <button>Enter</button>
        </form>
        <h2>{this.state.message}</h2>
      </div>
    );
  }
}
export default SendItem;