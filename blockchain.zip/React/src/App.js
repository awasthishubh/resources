import React, { Component } from 'react';
import './App.css';
import web3 from './web3';
import { abi, address } from './factory';
//var abi = factory.abi;

import NewItem from './newitem';
import AddItem from './additem';
import SendItem from './senditem';
import SendMoney from './sendmoney';
import ViewItem from './viewitem';
const factory = new web3.eth.Contract(abi, address);
class App extends Component {
  state = {
    manager: '',
    balance: '',
    value: '',
    message: '',
    itemname: '',
    itemcode: '',
    itemcost: '',
    itemcount: '',
    receiverAddress: ''
  };

  async componentDidMount() {
    const manager = await factory.methods.manager().call();
    const accounts = await web3.eth.getAccounts();
    //const balance = await web3.eth.getBalance(factory.options.address);
    //const balance = await web3.eth.getBalance(accounts[0]);
    const message = accounts;

    this.setState({ manager, message });
  }

  syncAddress = (addr) => {
    this.setState({ receiverAddress: addr });
  }

  render() {
    return (
      <div>
        <h2>Factory Contract</h2>
        <p>
          This contract is managed by {this.state.manager}. This contract has{' '}
          {web3.utils.fromWei(this.state.balance, 'ether')} ether! your address is
          {this.state.message}
        </p>
          <hr />
        <div style={{ display: 'flex', flexDirection: 'column', padding:30 }}>
          <div style={{ display: 'flex', flex: 1 }}>
            <NewItem />
            <SendItem syncAddress={this.syncAddress} />
          </div>
          <div style={{ display: 'flex', flex: 1 }}>
            <SendMoney to={this.state.receiverAddress} />
            <ViewItem />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
